const AWS = require('aws-sdk');
const https = require('https');
const rp = require('request-promise-native');
const cheerio = require('cheerio');

exports.handler = function(event, context, callback) {
    var API = JSON.parse(event.body);
    console.log('API: ' + API)
    console.log('URL: ' + API.url);
    console.log('Format: ' + API.format);
    switch (API.format) {
        case 'website':
            rp({
                uri: API.url,
                transform: function(body) {
                    return cheerio.load(body);
                }
            }).then(($) => {
                var citation = API
                citation.container = $('meta[property="og:title"]').attr('content')
                if (citation.container == null) {
                    citation.container = $('title').text()
                }
                citation.source = $('meta[property="og:site_name"]').attr('content')
                citation.authors = $('meta[property="article:author"]').attr('content')
                citation.publisher = $('meta[property="article:publisher"]').attr('content')
                citation.datePublished = $('meta[property="article:modified_time"]').attr('content')
                if (citation.datePublished == null) {
                    citation.datePublished = $('meta[property="og:published_time"]').attr('content')
                }
                if (citation.datePublished != null) {
                    citation.datePublished = new Date(citation.datePublished)
                    citation.datePublished = {
                        month: citation.datePublished.getMonth(), 
                        day: citation.datePublished.getDate(), 
                        year: citation.datePublished.getFullYear()
                    }
                }
                console.log('Citation: ' + citation)
                var response = {
                    "statusCode": 200,
                    "headers": {
                        "api-key": "none"
                    },
                    "body": JSON.stringify(citation),
                    "isBase64Encoded": false
                };
                callback(null, response);
            });
        break;
        default:
            console.log('Format is invalid');
            console.log("request: " + JSON.stringify(event));
            body = "{error: bad request}"
            var response = {
                "statusCode": 400,
                "headers": {
                    "api-key": "none"
                },
                "body": JSON.stringify(body),
                "isBase64Encoded": false
            };
            callback(null, response);
    }
}